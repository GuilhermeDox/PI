const bs = require('./_config/bootstrap')

bs()